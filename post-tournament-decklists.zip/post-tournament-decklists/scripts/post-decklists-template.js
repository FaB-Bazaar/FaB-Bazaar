require('dotenv').config();
const { Client, GatewayIntentBits, ChannelType } = require('discord.js');

const SERVER_ID = '1363266475988750407';
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// ── Fill these in ──────────────────────────────────────────────
const EVENT_NAME   = '{EVENT_NAME}';        // e.g. "Pro Tour Yokohama"
const EVENT_FORMAT = '{EVENT_FORMAT}';      // e.g. "Classic Constructed"
const CHANNEL_NAME = '{CHANNEL_NAME}';      // cc | silver-age | blitz
const EVENT_URL    = '{EVENT_URL}';         // fabbazaar.app event page

// place: "🥇 1st" | "🥈 2nd" | "🥉 3rd" | "   5th"
const TOP8 = [
  { place: '🥇 1st', hero: '',  player: '', id: '' },
  { place: '🥈 2nd', hero: '',  player: '', id: '' },
  { place: '🥉 3rd', hero: '',  player: '', id: '' },
  { place: '🥉 3rd', hero: '',  player: '', id: '' },
  { place: '   5th', hero: '',  player: '', id: '' },
  { place: '   5th', hero: '',  player: '', id: '' },
  { place: '   5th', hero: '',  player: '', id: '' },
  { place: '   5th', hero: '',  player: '', id: '' },
];
// ──────────────────────────────────────────────────────────────

client.once('ready', async () => {
  const guild = client.guilds.cache.get(SERVER_ID);
  await guild.channels.fetch();

  const channel = guild.channels.cache.find(
    ch => ch.name === CHANNEL_NAME && ch.type === ChannelType.GuildText
  );

  if (!channel) {
    console.error(`❌ #${CHANNEL_NAME} channel not found`);
    process.exit(1);
  }

  console.log(`✅ Found channel: #${channel.name}`);

  const mainMsg = await channel.send(
    `🏆 **${EVENT_NAME} — Top 8 ${EVENT_FORMAT} Decklists**\n\n` +
    `The best ${EVENT_FORMAT} lists from ${EVENT_NAME}. ` +
    `See the full event breakdown here:\n<${EVENT_URL}>\n\n` +
    `📋 Individual decklists are in the thread below ↓`
  );

  console.log('✅ Main message sent');

  const thread = await mainMsg.startThread({
    name: `${EVENT_NAME} — Top 8 ${EVENT_FORMAT}`,
    autoArchiveDuration: 10080, // 7 days
  });

  console.log(`✅ Thread created: ${thread.name}`);

  for (const deck of TOP8) {
    const url = `https://fabbazaar.app/decks/${deck.id}`;
    await thread.send(`${deck.place} — **${deck.hero}** (${deck.player})\n${url}`);
    console.log(`  📌 Posted: ${deck.hero} (${deck.player})`);
    await new Promise(r => setTimeout(r, 400));
  }

  console.log(`\n🎉 Done! Post + thread created in #${CHANNEL_NAME}.`);
  process.exit(0);
});

client.login(process.env.DISCORD_BOT_TOKEN);
