---
name: post-tournament-decklists
description: Post FaB tournament Top 8 decklists to the FaB Bazaar Discord server. This skill should be used when the user wants to post tournament Top 8 decklists (CC, Silver Age, or Blitz) to the appropriate Discord channel with a threaded list of decklist links. Trigger phrases include "post the top 8 decklists for [event]", "post [event] decklists to Discord", or "post [format] decklists for [event]".
---

# Post Tournament Decklists

Post a tournament's Top 8 decklists to the FaB Bazaar Discord server. Creates a main announcement message in the correct channel and a thread with individual deck links.

## Paths

- Discord bot scripts: `/Users/eko/fab-discord-bot/`
- Script template: `scripts/post-decklists-template.js` (in this skill — copy and fill in)
- Format → channel: `CC → #cc`, `Silver Age → #silver-age`, `Blitz → #blitz`

## Workflow

### Step 1 — Find decks via MCP

Call `mcp__fabby__list_decks` with the relevant format filter (`"CC"`, `"Silver Age"`, or `"Blitz"`). Identify the 8 decks that match the tournament name AND have a non-zero card count. Determine placement from the deck name (1st, 2nd, 3rd, 5th).

> Some deck names use "Pro Tour" and others use "PT" — account for both when scanning results.

### Step 2 — Get public IDs from the VPS

Claude cannot access the VPS database directly. Give the user this ready-to-run query (substitute `{TOURNAMENT}` and `{FORMAT}`):

```bash
docker exec fabbazaar-postgres psql -U fabbazaar -d fabbazaar -c "SELECT public_id, name FROM decks WHERE (name ILIKE '%{TOURNAMENT}%') AND format = '{FORMAT}' AND (SELECT COUNT(*) FROM deck_cards WHERE deck_id = decks.id) > 0 ORDER BY name;" | cat
```

If deck names use inconsistent prefixes (e.g. "PT Yokohama" vs "Pro Tour: Yokohama"), run a second query or broaden the ILIKE pattern. Wait for the user to paste the results before continuing.

### Step 3 — Generate and run the script

Copy `scripts/post-decklists-template.js` from this skill into `/Users/eko/fab-discord-bot/post-{event-slug}-{format-slug}.js`. Fill in:

- `EVENT_NAME` — e.g. `"Pro Tour Yokohama"`
- `EVENT_FORMAT` — e.g. `"Classic Constructed"`
- `CHANNEL_NAME` — `cc`, `silver-age`, or `blitz`
- `EVENT_URL` — fabbazaar.app event page (provided by user, or omit section if unknown)
- `TOP8` array — 8 entries with `place`, `hero`, `player`, `id` (public_id from Step 2)

Then run:

```bash
cd /Users/eko/fab-discord-bot && node post-{event-slug}-{format-slug}.js
```

## Placement Format

| Finish | `place` value |
|--------|--------------|
| 1st    | `🥇 1st` |
| 2nd    | `🥈 2nd` |
| 3rd    | `🥉 3rd` |
| 5th+   | `   5th` (3 spaces + number for alignment) |

## Message Format Reference

**Main channel message:**
```
🏆 **{Event} — Top 8 {Format} Decklists**

The best {Format} lists from {Event} ({Date}). See the full event breakdown here:
<{EVENT_URL}>

📋 Individual decklists are in the thread below ↓
```

> Always wrap the event URL in `<>` to suppress Discord's embed preview.

**Thread posts** (one per deck, in finishing order):
```
{medal} {place} — **{Hero}** ({Player})
https://fabbazaar.app/decks/{public_id}
```

> Do NOT wrap deck URLs in `<>` — the card art preview embed is desirable in threads.

**Thread settings:**
- `name`: `"{Event} — Top 8 {Format}"`
- `autoArchiveDuration`: `10080` (7 days)
