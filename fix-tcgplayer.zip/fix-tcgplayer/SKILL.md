---
name: fix-tcgplayer
description: Fix incorrect TCGplayer data (product ID, URL, foil/subtype name) on a FaB Bazaar printing row. This skill should be used when the user provides a printing ID and reports that one or more TCGplayer fields are wrong and need to be corrected via a direct database update on the VPS.
---

# fix-tcgplayer

## Overview

Generate a ready-to-run `docker exec` psql command to correct TCGplayer fields on a printing row in the FaB Bazaar production database.

## Database Details

- **Container**: `fabbazaar-postgres`
- **User / DB**: `fabbazaar` / `fabbazaar`
- **Table**: `printings`
- **Relevant columns**:
  - `printing_id` — primary key (alphanumeric public ID, e.g. `GKzW9mhtMFRMfQNzpNcw8`)
  - `tcgplayer_product_id` — integer product ID from TCGplayer URL
  - `tcgplayer_url` — clean base URL (no query params), e.g. `https://www.tcgplayer.com/product/657480/flesh-and-blood-tcg-...`
  - `tcgplayer_subtype_name` — foil type string: `Rainbow Foil`, `Cold Foil`, or `NULL` for non-foil

## Workflow

### Step 1: Confirm what to fix

Identify from the user's message:
- The `printing_id` (one or more)
- The correct `tcgplayer_product_id` (integer extracted from the TCGplayer URL)
- The correct `tcgplayer_url` (strip query params — keep only the path portion)
- The correct `tcgplayer_subtype_name` (`Rainbow Foil`, `Cold Foil`, or omit if not changing)

If the TCGplayer URL is provided, extract the product ID from it (it's the number after `/product/`).

Strip query params from the URL before using it (e.g. `?Printing=Cold+Foil&Language=all&page=1` → remove).

### Step 2: Output the command

Produce a single `docker exec` command per printing ID. Only include columns that are actually being changed.

**Template (all three fields):**
```bash
docker exec -i fabbazaar-postgres psql -U fabbazaar -d fabbazaar -c "
UPDATE printings
SET
  tcgplayer_product_id = <PRODUCT_ID>,
  tcgplayer_url = '<CLEAN_URL>',
  tcgplayer_subtype_name = '<FOIL_TYPE>'
WHERE printing_id = '<PRINTING_ID>';
"
```

**Template (product ID + URL only, no foil change):**
```bash
docker exec -i fabbazaar-postgres psql -U fabbazaar -d fabbazaar -c "
UPDATE printings
SET
  tcgplayer_product_id = <PRODUCT_ID>,
  tcgplayer_url = '<CLEAN_URL>'
WHERE printing_id = '<PRINTING_ID>';
"
```

### Step 3: Verify query (optional)

If the user wants to confirm after running the update, provide this SELECT:

```bash
docker exec -i fabbazaar-postgres psql -U fabbazaar -d fabbazaar -c "
SELECT printing_id, tcgplayer_product_id, tcgplayer_url, tcgplayer_subtype_name
FROM printings
WHERE printing_id IN ('<PRINTING_ID>');
"
```

## Notes

- Multiple printing IDs can be fixed in one session — output one command per row.
- `tcgplayer_subtype_name` valid values: `Rainbow Foil`, `Cold Foil`, `NULL` (set to NULL with `tcgplayer_subtype_name = NULL` — no quotes).
- Run commands on the VPS as `root@hwsrv-1305736` in `/opt/fabbazaar`.
